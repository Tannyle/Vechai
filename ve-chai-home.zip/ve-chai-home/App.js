import React, {Component} from 'react';
import { Text, View, StyleSheet, Button, Image } from 'react-native';
import Constants from 'expo-constants';



export default class App extends React.Component {
  constructor(props){
    super(props);
    this.state = {chai:0, tui:0, giay:0, can:0};
  }
  plus1 = (event) => {
    event.preventDefault();
    let plustui = this.state.tui;
    this.setState({tui: ++plustui})
  }
  minus1 = (event) => {
    event.preventDefault();
    let minustui = this.state.tui;
    this.setState({tui: --minustui})
  }
  plus2 = (event) => {
    event.preventDefault();
    let pluschai = this.state.chai;
    this.setState({chai: ++pluschai})
  }
  minus2 = (event) => {
    event.preventDefault();
    let minuschai = this.state.chai;
    this.setState({chai: --minuschai})
  }
  plus3 = (event) => {
    event.preventDefault();
    let plusgiay = this.state.giay;
    this.setState({giay: ++plusgiay})
  }
  minus3 = (event) => {
    event.preventDefault();
    let minusgiay = this.state.giay;
    this.setState({giay: --minusgiay})
  }
  plus4 = (event) => {
    event.preventDefault();
    let pluscan = this.state.can;
    this.setState({can: ++pluscan})
  }
  minus4 = (event) => {
    event.preventDefault();
    let minuscan = this.state.can;
    this.setState({can: --minuscan})
  }
  render() {
    return (
      <View style={{
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center'
      }}>
        
        <View style={{ flexDirection: 'row', justifyContent: 'space-around' }}>
          <Image source={{uri: 'https://cdn2.iconfinder.com/data/icons/waste-management-and-recycling/64/plastic_bag-512.png'}}
                style={{width: 70, height: 70}}
          />
          <Text style={styles.paragraph}>Túi nilon:</Text>
          <Text style={styles.paragraph}>{this.state.tui} túi</Text>
          <View style={{ backgroundColor:"white", borderRadius:20, alignContent: 'flex-end'}}>
            <Button onPress = {this.plus1}
            title="+"
            color="lightgrey"
            >
            </Button>
            <Button onPress = {this.minus1}
            title="-"
            color="lightgrey"
            >
            </Button>
          </View>
        </View>
        <Text style={styles.paragraph1}> </Text>
        <View style={{ flexDirection: 'row', justifyContent: 'space-around' }}>
          <Image source={{uri: 'https://cdn4.iconfinder.com/data/icons/plastic-package/48/69_plastic-packaging-package-bottle-512.png'}}
                style={{width: 70, height: 70}}
          />
          <Text style={styles.paragraph}>Nhựa:   </Text>
          <Text style={styles.paragraph}>{this.state.chai} chai</Text>
          <View style={{ backgroundColor:"white", borderRadius:20, alignContent: 'flex-end'}}>
            <Button onPress = {this.plus2}
            title="+"
            color="lightgrey"
            >
            </Button>
            <Button onPress = {this.minus2}
            title="-"
            color="lightgrey"
            >
            </Button>
          </View>
        </View>
        <Text style={styles.paragraph1}> </Text>
        <View style={{ flexDirection: 'row', justifyContent: 'space-around' }}>
          <Image source={{uri: 'https://cdn3.iconfinder.com/data/icons/business-office-and-factory/100/box3-512.png'}}
                style={{width: 70, height: 70}}
          />
          <Text style={styles.paragraph}>Giấy:        </Text>
          <Text style={styles.paragraph}>{this.state.giay} kg</Text>
          <View style={{ backgroundColor:"white", borderRadius:20, alignContent: 'flex-end'}}>
            <Button onPress = {this.plus3}
            title="+"
            color="lightgrey"
            >
            </Button>
            <Button onPress = {this.minus3}
            title="-"
            color="lightgrey"
            >
            </Button>
          </View>
        </View>
        <Text style={styles.paragraph1}> </Text>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
          <Image source={{uri: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRwCbVBH_jthGbfqNEq_Dojqgdvy4SURHrIk1rkRrm1g2K56MSn'}}
                style={{width: 70, height: 70}}
          />
          <Text style={styles.paragraph}>Vỏ lon:   </Text>
          <Text style={styles.paragraph}>{this.state.can} lon</Text>
          <View style={{ backgroundColor:"white", borderRadius:20, alignContent: 'flex-end'}}>
            <Button onPress = {this.plus4}
            title="+"
            color="lightgrey"
            >
            </Button>
            <Button onPress = {this.minus4}
            title="-"
            color="lightgrey"
            >
            </Button>
          </View>
        </View>


      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  paragraph1: {
    margin: 24,
    fontSize: 2,
    fontWeight: 'bold',
    textAlign: 'center',
  },
});
